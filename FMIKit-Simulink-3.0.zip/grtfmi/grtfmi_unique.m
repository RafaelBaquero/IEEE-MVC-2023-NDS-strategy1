function b = grtfmi_unique(a)

b = cellstr(a);
b = unique(b);

end
