function builddir = grtfmi_build_directory()


builddir = rtwprivate('get_makertwsettings',gcs,'BuildDirectory');


end

