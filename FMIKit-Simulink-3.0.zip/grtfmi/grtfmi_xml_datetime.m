function [ time_and_date ] = grtfmi_xml_datetime()

time_and_date = datestr(now, 'yyyy-mm-ddTHH:MM:SS');

end
