function v = version()
% FMIKit.version  Get the version of FMI Kit

v = '3.0';

end
