#define FMI_VERSION 2

#include "fmi2Functions.c"
#include "model.c"
#include "slave.c"
